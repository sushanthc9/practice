package com.ilp.test;

import java.util.ArrayList;
import java.util.List;

public class Student {
	
	private String name;
	private int roll;
	private List<String> myList;
	
	public List<String> getMyList() {
		return myList;
	}
	public void setMyList(List<String> myList) {
		this.myList = myList;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	
	public String showDetails(){
		
		System.out.println("Name: " +name);
		System.out.println("Roll: " + roll);	
		
		myList = new ArrayList<String>();
		
		myList.add("Dhananjay");
		myList.add("Akash");
		myList.add("Mahesh");
		myList.add("Rahul");
		
		System.out.println("MyList Size :: " + myList.size());
		
		
		
		//call DAO
		
		return "done";
	} 

}
