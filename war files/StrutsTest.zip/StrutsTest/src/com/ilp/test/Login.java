package com.ilp.test;

import java.util.Map;


import org.apache.struts2.dispatcher.SessionMap;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class Login extends ActionSupport implements SessionAware{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;
	private SessionMap<String,String> sessionMap;
	
	public SessionMap<String, String> getSessionMap() {
			
		return sessionMap;
	}
	public void setSessionMap(SessionMap<String, String> sessionMap) {
		
		this.sessionMap = sessionMap;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String doLogin(){
		
		if(this.userName.equals("admin") && this.password.equals("admin")){
					
			
			//sessionMap.put("username", userName);
		//	sessionMap.put("login","true");
			sessionMap.put("","true");
			addActionMessage("Welcome" + userName);
			
			return "done";
			
		}else{
			
			//addActionError("Error Username or Password");			
			return "error";
		}
		
		
	}
	@Override
	public void setSession(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		sessionMap = (SessionMap)arg0;
		
		
	}
	
}
